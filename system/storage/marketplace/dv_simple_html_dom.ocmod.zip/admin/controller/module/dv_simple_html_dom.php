<?php
namespace Opencart\Catalog\Controller\Extension\DvSimpleHtmlDom\Module;

class AjaxQuickCheckout extends \Opencart\System\Engine\Controller {
    public function install (): void {
        
    }
}